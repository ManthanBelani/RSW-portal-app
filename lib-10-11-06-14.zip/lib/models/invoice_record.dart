class InvoiceRecord {
  final String id;
  final String invoiceRef;
  final String createdBy;
  final String createdAt;
  final String client;
  final String project;
  final double amount;
  final double paidamount;
  final String currencyCode;
  final double expenseAmount;
  final double profitLoss;
  final String invoiceStatus; // Paid, Unpaid, Partially Paid
  final String workStatus; // Pending, Completed
  final DateTime workStartDate;
  final DateTime workEndDate;

  InvoiceRecord({
    required this.id,
    required this.createdAt,
    required this.invoiceRef,
    required this.createdBy,
    required this.client,
    required this.paidamount,
    required this.project,
    required this.amount,
    required this.currencyCode,
    required this.expenseAmount,
    required this.profitLoss,
    required this.invoiceStatus,
    required this.workStatus,
    required this.workStartDate,
    required this.workEndDate,
  });

  factory InvoiceRecord.fromApiJson(Map<String, dynamic> json) {
    // Parse invoice payment status
    String invoiceStatus = 'Unpaid';
    final isPaid = json['is_paid'];
    if (isPaid == 1 || isPaid == '1') {
      invoiceStatus = 'Paid';
    } else if (isPaid == 2 || isPaid == '2') {
      invoiceStatus = 'Partially Paid';
    }

    // Extract work_info object
    final workInfo = json['work_info'] as Map<String, dynamic>?;

    // Parse work completion status from work_info
    String workStatus = 'Pending';
    if (workInfo != null) {
      final isCompleted = workInfo['is_completed'];
      if (isCompleted == 1 || isCompleted == '1') {
        workStatus = 'Completed';
      }
    }

    // Get dates from work_info
    String? workStartDate = workInfo?['work_start_date'];
    String? workEndDate = workInfo?['work_end_date'];

    return InvoiceRecord(
      id: json['id']?.toString() ?? '',
      invoiceRef: json['reference'] ?? '',
      createdBy: json['created_by'] ?? '',
      client: json['client_name'] ?? '',
      project: json['project'] ?? '',
      paidamount: double.tryParse(json['paid_amount']?.toString() ?? '0') ?? 0.0,
      amount: double.tryParse(json['invoice_rate']?.toString() ?? '0') ?? 0.0,
      currencyCode: json['currency_code'] ?? 'USD',
      expenseAmount:
          double.tryParse(json['expense_amount']?.toString() ?? '0') ?? 0.0,
      profitLoss: double.tryParse(json['profit']?.toString() ?? '0') ?? 0.0,
      invoiceStatus: invoiceStatus,
      workStatus: workStatus,
      workStartDate: _parseDate(workStartDate),
      workEndDate: _parseDate(workEndDate),
      createdAt: json['created_at'],
    );
  }

  static DateTime _parseDate(dynamic dateStr) {
    if (dateStr == null || dateStr.toString().isEmpty) {
      return DateTime.now();
    }
    try {
      return DateTime.parse(dateStr.toString());
    } catch (e) {
      return DateTime.now();
    }
  }

  factory InvoiceRecord.fromJson(Map<String, dynamic> json) {
    return InvoiceRecord(
      id: json['id'] ?? '',
      createdAt: json['created_at'],
      invoiceRef: json['invoice_ref'] ?? '',
      createdBy: json['created_by'] ?? '',
      client: json['client'] ?? '',
      project: json['project'] ?? '',
      amount: (json['amount'] ?? 0).toDouble(),
      currencyCode: json['currency_code'] ?? 'USD',
      expenseAmount: (json['expense_amount'] ?? 0).toDouble(),
      profitLoss: (json['profit_loss'] ?? 0).toDouble(),
      invoiceStatus: json['invoice_status'] ?? '',
      workStatus: json['work_status'] ?? '',
      workStartDate: DateTime.parse(json['work_start_date']),
      workEndDate: DateTime.parse(json['work_end_date']),
      paidamount:(json['paid_amount'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'invoice_ref': invoiceRef,
      'created_by': createdBy,
      'client': client,
      'project': project,
      'amount': amount,
      'currency_code': currencyCode,
      'expense_amount': expenseAmount,
      'profit_loss': profitLoss,
      'invoice_status': invoiceStatus,
      'work_status': workStatus,
      'work_start_date': workStartDate.toIso8601String(),
      'work_end_date': workEndDate.toIso8601String(),
    };
  }
}
