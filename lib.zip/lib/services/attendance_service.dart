import 'package:flutter_dotenv/flutter_dotenv.dart';

import '../models/attendance_model.dart';
import 'api_client.dart';

class AttendanceService {
  static String get _baseUrl {
    return dotenv.env['BASE_URL'] ?? 'https://rainflowweb.com/demo/account-upgrade/api';
  }
  
  static Future<AttendanceResponse> fetchAttendanceData() async {
    try {
      // Use ApiClient for authenticated request
      final response = await ApiClient.get('$_baseUrl/attendance');

      if (response.statusCode == 200) {
        final json = ApiClient.parseJsonResponse(response);
        return AttendanceResponse.fromJson(json);
      } else {
        throw Exception('Failed to load attendance data: ${response.statusCode}');
      }
    } on ApiException catch (e) {
      throw Exception(e.message);
    } catch (e) {
      throw Exception('Error fetching attendance data: $e');
    }
  }

  static Future<AttendanceResponse> fetchAttendanceDataByDateRange(DateTime startDate, DateTime endDate) async {
    try {
      final String formattedStartDate = "${startDate.year}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}";
      final String formattedEndDate = "${endDate.year}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}";
      
      // Use ApiClient for authenticated request
      final response = await ApiClient.get(
        '$_baseUrl/attendance?start_date=$formattedStartDate&end_date=$formattedEndDate',
      );

      if (response.statusCode == 200) {
        final json = ApiClient.parseJsonResponse(response);
        return AttendanceResponse.fromJson(json);
      } else {
        throw Exception('Failed to load attendance data: ${response.statusCode}');
      }
    } on ApiException catch (e) {
      throw Exception(e.message);
    } catch (e) {
      throw Exception('Error fetching attendance data: $e');
    }
  }
}