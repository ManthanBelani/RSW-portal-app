import 'dart:ui';

final primaryColor = Color(0xFFFC3342);

final white = Color(0xFFFFFFFF);

final primaryColor1 = Color(0xFFF4747E);

final backButtonColor = Color(0xFF3366FF);