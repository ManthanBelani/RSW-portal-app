import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as mt;
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import '../constants/constants.dart';

class InvoicePreviewAndDownloadScreen extends StatefulWidget {
  final Map<String, dynamic> invoiceData;
  final Map<String, dynamic>? clientData;
  final Map<String, dynamic>? selectedClient;
  final Map<String, dynamic>? selectedCurrency;
  final Map<String, dynamic>? values;

  const InvoicePreviewAndDownloadScreen({
    super.key,
    required this.invoiceData,
    this.clientData,
    this.selectedClient,
    this.selectedCurrency,
    this.values,
  });

  @override
  State<InvoicePreviewAndDownloadScreen> createState() =>
      _InvoicePreviewAndDownloadScreenState();
}

class _InvoicePreviewAndDownloadScreenState
    extends State<InvoicePreviewAndDownloadScreen> {
  bool _isGenerating = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Invoice Preview'),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: _isGenerating ? null : _downloadPDF,
            tooltip: 'Download PDF',
          ),
          // IconButton(
          //   icon: const Icon(Icons.share),
          //   onPressed: _isGenerating ? null : _sharePDF,
          //   tooltip: 'Share PDF',
          // ),
        ],
      ),
      body: _isGenerating
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: primaryColor),
                  const SizedBox(height: 16),
                  const Text('Generating PDF...'),
                ],
              ),
            )
          : PdfPreview(
              build: (format) async {
                try {
                  return await _generatePDF(format);
                } catch (e) {
                  print('❌ PDF Preview Error: $e');
                  // Return a simple error PDF
                  final pdf = pw.Document();
                  pdf.addPage(
                    pw.Page(
                      build: (context) =>
                          pw.Center(child: pw.Text('Error generating PDF: $e')),
                    ),
                  );
                  return pdf.save();
                }
              },
              canChangePageFormat: false,
              canChangeOrientation: false,
              canDebug: true,
              pdfFileName:
                  'Invoice_${widget.invoiceData['invoice_no'] ?? 'document'}.pdf',
            ),
    );
  }

  Future<Uint8List> _generatePDF(PdfPageFormat format) async {
    try {
      print('📄 Starting PDF generation...');
      final pdf = pw.Document();

      // Try to load logo, but continue if it fails
      pw.MemoryImage? logoImage;
      try {
        print('🖼️ Loading logo...');
        final logoData = await rootBundle.load('assets/images/namedlogo1.png');
        logoImage = pw.MemoryImage(logoData.buffer.asUint8List());
        print('✅ Logo loaded successfully');
      } catch (e) {
        print('⚠️ Logo not found, continuing without it: $e');
      }

      // Load fonts for better text rendering using Google Fonts
      print('🔤 Loading fonts...');
      final ttf = await PdfGoogleFonts.openSansRegular();
      final ttfBold = await PdfGoogleFonts.openSansBold();
      print('✅ Fonts loaded successfully');

      print('📋 Building PDF page...');
      print('   Invoice data: ${widget.invoiceData}');
      print('   Client: ${widget.selectedClient}');
      print('   Currency: ${widget.selectedCurrency}');

      pdf.addPage(
        pw.Page(
          pageFormat: format,
          margin: const pw.EdgeInsets.all(40),
          build: (context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                _buildHeader(logoImage, ttf, ttfBold),
                pw.SizedBox(height: 40),
                _buildInvoiceInfo(ttf, ttfBold),
                pw.SizedBox(height: 30),
                _buildItemsTable(ttf, ttfBold),
                pw.SizedBox(height: 20),
                _buildTotals(ttf, ttfBold),
                pw.Spacer(),
                if (widget.values?['notice'] != null &&
                    widget.values!['notice'].toString().isNotEmpty)
                  _buildNotice(ttf, ttfBold),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  children: [
                    pw.Container(
                      width: 200,
                      padding: const pw.EdgeInsets.symmetric(
                        horizontal: 15,
                        vertical: 10,
                      ),
                      decoration: pw.BoxDecoration(
                        color: PdfColor.fromHex('#FC3342'),
                        borderRadius: pw.BorderRadius.circular(25),
                      ),
                      child: pw.Center(
                        child: pw.Text(
                          'Thank you',
                          style: pw.TextStyle(
                            fontSize: 12,
                            color: PdfColor.fromHex('#FFFFFF94'),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                pw.SizedBox(height: 20),
                _buildFooter(ttf),
              ],
            );
          },
        ),
      );

      print('💾 Saving PDF...');
      final bytes = await pdf.save();
      print('✅ PDF generated successfully (${bytes.length} bytes)');
      return bytes;
    } catch (e, stackTrace) {
      print('❌ Error generating PDF: $e');
      print('❌ Stack trace: $stackTrace');
      rethrow;
    }
  }

  pw.Widget _buildHeader(pw.MemoryImage? logo, pw.Font font, pw.Font fontBold) {
    return pw.Stack(
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            // Left side - Company Logo and Info
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                if (logo != null) ...[
                  pw.Image(logo, width: 150),
                  pw.SizedBox(height: 20),
                ],
                pw.Text(
                  'ISSUER:',
                  style: pw.TextStyle(
                    font: fontBold,
                    fontSize: 9,
                    color: PdfColor.fromHex('#FC3342'),
                  ),
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  'Rainstream Technologies',
                  style: pw.TextStyle(font: fontBold, fontSize: 8),
                ),
                pw.Text(
                  '1111, Anam 2, Ambli Bopal,',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
                pw.Text(
                  'Junction, Nr. Bopal Flyover,',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
                pw.Text(
                  'Ambli, Ahmedabad, Gujarat 380058',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
                pw.Text(
                  '✉ rainstreamweb@gmail.com',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
                pw.Text(
                  '📞 +91 9512566601',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
                pw.Text(
                  'GSTIN: 24AOLPJ1440C1ZI',
                  style: pw.TextStyle(font: font, fontSize: 7),
                ),
              ],
            ),
            // Right side - Invoice badge with curved design
            pw.Container(
              width: 250,
              height: 150,
              child: pw.Stack(
                children: [
                  // Pink curved background
                  pw.Positioned(
                    right: -50,
                    top: -20,
                    child: pw.Container(
                      width: 300,
                      height: 200,
                      decoration: pw.BoxDecoration(
                        color: PdfColor.fromHex('#FC3342'),
                        borderRadius: pw.BorderRadius.circular(100),
                      ),
                    ),
                  ),
                  // Invoice text
                  pw.Positioned(
                    right: 20,
                    top: 30,
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Text(
                          'INVOICE',
                          style: pw.TextStyle(
                            font: fontBold,
                            fontSize: 24,
                            color: PdfColors.white,
                          ),
                        ),
                        pw.SizedBox(height: 15),
                        pw.Text(
                          'Invoice No: ${widget.invoiceData['invoice_no'] ?? ''}',
                          style: pw.TextStyle(
                            font: font,
                            fontSize: 8,
                            color: PdfColors.white,
                          ),
                        ),
                        pw.Text(
                          'Invoice Date: ${widget.invoiceData['invoice_date'] ?? ''}',
                          style: pw.TextStyle(
                            font: font,
                            fontSize: 8,
                            color: PdfColors.white,
                          ),
                        ),
                        pw.Text(
                          'Due Date: ${widget.invoiceData['due_date'] ?? ''}',
                          style: pw.TextStyle(
                            font: font,
                            fontSize: 8,
                            color: PdfColors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  pw.Widget _buildInvoiceInfo(pw.Font font, pw.Font fontBold) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'CUSTOMER:',
          style: pw.TextStyle(
            font: fontBold,
            fontSize: 10,
            color: PdfColor.fromHex('#FC3342'),
          ),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          widget.selectedClient?['client_name'] ?? '',
          style: pw.TextStyle(font: fontBold, fontSize: 9),
        ),
        if (widget.values?['client_address'] != null)
          pw.Text(
            widget.values!['client_address'],
            style: pw.TextStyle(font: font, fontSize: 8),
          ),
      ],
    );
  }

  pw.Widget _buildItemsTable(pw.Font font, pw.Font fontBold) {
    final tasks = widget.invoiceData['tasks'] as List<dynamic>? ?? [];

    return pw.Column(
      children: [
        // Header
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          decoration: pw.BoxDecoration(
            color: PdfColor.fromHex('#FC3342'),
            borderRadius: const pw.BorderRadius.only(
              topLeft: pw.Radius.circular(15),
              topRight: pw.Radius.circular(15),
            ),
          ),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Expanded(
                flex: 3,
                child: pw.Text(
                  'DESCRIPTION',
                  style: pw.TextStyle(
                    font: fontBold,
                    fontSize: 10,
                    color: PdfColors.white,
                  ),
                ),
              ),
              pw.Expanded(
                flex: 1,
                child: pw.Text(
                  'AMOUNT',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(
                    font: fontBold,
                    fontSize: 10,
                    color: PdfColors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
        // Data rows
        ...tasks.map((task) {
          return pw.Container(
            padding: const pw.EdgeInsets.symmetric(
              horizontal: 15,
              vertical: 10,
            ),
            decoration: pw.BoxDecoration(
              border: pw.Border(
                bottom: pw.BorderSide(color: PdfColors.grey300),
              ),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Expanded(
                  flex: 3,
                  child: pw.Text(
                    task['description'] ?? '',
                    style: pw.TextStyle(font: font, fontSize: 9),
                  ),
                ),
                pw.Expanded(
                  flex: 1,
                  child: pw.Text(
                    '${widget.selectedCurrency?['currency_code'] ?? ''} ${task['amount'] ?? '0'}',
                    textAlign: pw.TextAlign.right,
                    style: pw.TextStyle(font: fontBold, fontSize: 9),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  pw.Widget _buildTotals(pw.Font font, pw.Font fontBold) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(15),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.end,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              // Show discount if any
              if (widget.invoiceData['discount'] != null &&
                  widget.invoiceData['discount'] != '0')
                pw.Padding(
                  padding: const pw.EdgeInsets.only(bottom: 5),
                  child: pw.Text(
                    '${widget.invoiceData['discount_label'] ?? 'Discount'}: -${widget.invoiceData['discount']} ${widget.selectedCurrency?['currency_code'] ?? ''}',
                    style: pw.TextStyle(font: font, fontSize: 9),
                  ),
                ),
              // Total Amount
              pw.Text(
                'Total Amount: ${widget.selectedCurrency?['currency'] ?? ''} ${widget.invoiceData['total_due'] ?? widget.invoiceData['subtotal'] ?? '0'}',
                style: pw.TextStyle(
                  font: fontBold,
                  fontSize: 11,
                  color: PdfColors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  pw.Widget _buildNotice(pw.Font font, pw.Font fontBold) {
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'NOTICE: ',
          style: pw.TextStyle(
            font: fontBold,
            fontSize: 10,
            color: PdfColor.fromHex('#FC3342'),
          ),
        ),
        pw.Expanded(
          child: pw.Text(
            widget.values!['notice'],
            style: pw.TextStyle(font: font, fontSize: 9),
          ),
        ),
      ],
    );
  }

  pw.Widget _buildFooter(pw.Font font) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(20),
      decoration: pw.BoxDecoration(color: PdfColor.fromHex('#FC3342')),
      child: pw.Container(
        padding: const pw.EdgeInsets.symmetric(horizontal: 30, vertical: 15),
        decoration: pw.BoxDecoration(
          color: PdfColors.white,
          borderRadius: pw.BorderRadius.circular(30),
        ),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
          children: [
            pw.Row(
              children: [
                pw.Text(
                  'https://rainstreamweb.com',
                  style: pw.TextStyle(
                    font: font,
                    fontSize: 9,
                    color: PdfColors.black,
                  ),
                ),
              ],
            ),
            pw.Row(
              children: [
                // pw.Icon(&#xe0b0),
                pw.Text(
                  '+91 951 256 6601',
                  style: pw.TextStyle(
                    font: font,
                    fontSize: 9,
                    color: PdfColors.black,
                  ),
                ),
              ],
            ),
            pw.Row(
              children: [
                pw.Text('✉ ', style: pw.TextStyle(fontSize: 10)),
                pw.Text(
                  'info@rainstreamweb.com',
                  style: pw.TextStyle(
                    font: font,
                    fontSize: 9,
                    color: PdfColors.black,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _downloadPDF() async {
    setState(() => _isGenerating = true);

    try {
      final pdf = await _generatePDF(PdfPageFormat.a4);

      // Try to get Downloads directory, fallback to Documents if not available
      Directory? directory;
      if (Platform.isAndroid) {
        // For Android, try to get Downloads folder
        directory = Directory('/storage/emulated/0/Download');
        if (!await directory.exists()) {
          directory = await getExternalStorageDirectory();
        }
      } else {
        // For iOS, use Documents directory
        directory = await getApplicationDocumentsDirectory();
      }

      final fileName =
          'Invoice_${widget.invoiceData['invoice_no'] ?? DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File('${directory?.path}/$fileName');
      await file.writeAsBytes(pdf);

      print('✅ PDF saved to: ${file.path}');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('PDF saved to Downloads folder'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
            action: SnackBarAction(
              label: 'Open',
              textColor: Colors.white,
              onPressed: () async {
                await Printing.sharePdf(bytes: pdf, filename: fileName);
              },
            ),
          ),
        );
      }
    } catch (e) {
      print('❌ Error downloading PDF: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error downloading PDF: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() => _isGenerating = false);
    }
  }

  // Future<void> _sharePDF() async {
  //   setState(() => _isGenerating = true);
  //
  //   try {
  //     final pdf = await _generatePDF(PdfPageFormat.a4);
  //     await Printing.sharePdf(
  //       bytes: pdf,
  //       filename:
  //           'Invoice_${widget.invoiceData['invoice_no'] ?? 'document'}.pdf',
  //     );
  //   } catch (e) {
  //     if (mounted) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text('Error sharing PDF: $e'),
  //           backgroundColor: Colors.red,
  //         ),
  //       );
  //     }
  //   } finally {
  //     setState(() => _isGenerating = false);
  //   }
  // }
}
