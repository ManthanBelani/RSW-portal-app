# Invoice PDF Preview and Download Screen

## Required Dependencies

Add these dependencies to your `pubspec.yaml` file:

```yaml
dependencies:
  pdf: ^3.10.8
  printing: ^5.12.0
  path_provider: ^2.1.2
  share_plus: ^7.2.2
```

## Required Assets

Make sure you have these assets in your project:

1. **Logo**: `assets/logo/logo_light.png`
2. **Fonts** (for better PDF rendering):
   - `assets/fonts/OpenSans-Regular.ttf`
   - `assets/fonts/OpenSans-Bold.ttf`

Add them to your `pubspec.yaml`:

```yaml
flutter:
  assets:
    - assets/logo/logo_light.png
  
  fonts:
    - family: OpenSans
      fonts:
        - asset: assets/fonts/OpenSans-Regular.ttf
        - asset: assets/fonts/OpenSans-Bold.ttf
          weight: 700
```

## Installation Steps

1. Add the dependencies to `pubspec.yaml`
2. Run: `flutter pub get`
3. Download Open Sans fonts from Google Fonts and place them in `assets/fonts/`
4. Update your `pubspec.yaml` with the assets configuration above

## Usage Example

```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => InvoicePreviewAndDownloadScreen(
      invoiceData: {
        'invoice_no': 'INV-001',
        'invoice_date': '07/11/2025',
        'due_date': '14/11/2025',
        'tasks': [
          {
            'description': 'Web Development',
            'date': '01/11/2025',
            'hours': '8',
            'rate_per_hour': '50',
            'amount': '400',
          },
        ],
        'total_hours': '8',
        'rate_per_hour': '50',
        'total_due': '400',
      },
      selectedClient: {
        'client_name': 'Client Name',
      },
      selectedCurrency: {
        'currency_code': 'USD',
      },
      values: {
        'client_address': 'Client Address\nCity, State',
        'notice': 'Payment terms and conditions',
      },
    ),
  ),
);
```

## Features

- ✅ PDF Preview with native rendering
- ✅ Download PDF to device
- ✅ Share PDF via system share sheet
- ✅ Professional invoice layout matching your design
- ✅ Primary color theme (#FC3342)
- ✅ Responsive layout
- ✅ Support for multiple line items
- ✅ Bank details section
- ✅ Notice/Terms section
- ✅ Company branding

## Alternative: Simpler Implementation

If you don't want to use PDF packages, you can create a simpler HTML-based preview screen that uses WebView or Flutter's built-in widgets for preview only.
